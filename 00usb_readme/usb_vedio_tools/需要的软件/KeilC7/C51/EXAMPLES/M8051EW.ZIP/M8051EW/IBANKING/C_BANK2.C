/*------------------------------------------------------------------------------
C_BANK2.C

Copyright 1995-1996 Keil Software, Inc.
------------------------------------------------------------------------------*/

#include <stdio.h>

void func2(void) {
  printf("THIS IS A FUNCTION IN BANK 2! \n");
}
