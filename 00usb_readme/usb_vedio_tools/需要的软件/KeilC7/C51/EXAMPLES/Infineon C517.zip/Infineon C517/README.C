/****************************************************************************/
/*                                                                          */
/* This project exceedes the code size limits of the Evaluation Version     */
/* and cannot be modified/retranslated with the Evaluation Version.         */
/*                                                                          */
/* However you can debug a pre-compiled version with the uVision2 Debugger. */
/*                                                                          */
/****************************************************************************/

void main ()  {
  /* This is a dummy main routine */
  while (1)  {
    ;
  }
}

