unsigned char Polling_Encoder();
