unsigned char Key_check();
