// wdt_selfcalibration.h

#ifndef WDT_SELFCALIBRATION
#define WDT_SELFCALIBRATION

// includes for Usersoftware
#include "CSTM_lib.h"
#include "WDCAL_lib.h"
 
#endif
